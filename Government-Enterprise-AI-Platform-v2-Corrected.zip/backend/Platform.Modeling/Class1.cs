﻿namespace Platform.Modeling;

public class Class1
{

}
