﻿namespace Platform.Knowledge;

public class Class1
{

}
