﻿namespace Platform.Integrations;

public class Class1
{

}
