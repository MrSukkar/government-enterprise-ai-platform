﻿namespace Platform.Governance;

public class Class1
{

}
