﻿namespace Platform.EnterpriseModel;

public class Class1
{

}
