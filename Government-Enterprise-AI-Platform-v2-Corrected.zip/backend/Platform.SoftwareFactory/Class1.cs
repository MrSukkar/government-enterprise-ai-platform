﻿namespace Platform.SoftwareFactory;

public class Class1
{

}
